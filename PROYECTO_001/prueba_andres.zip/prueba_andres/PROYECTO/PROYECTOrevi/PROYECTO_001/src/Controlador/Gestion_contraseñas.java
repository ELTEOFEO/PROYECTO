package Controlador;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.UUID;

/**
 *
 * @author COSAS DE LA Y
 */
public class Gestion_contraseñas extends Arooz_con_papas {
    private static final SecureRandom random = new SecureRandom();

    @Override
    public String creador_contraseñas() {
       
        byte[] bytes = new byte[5];
        random.nextBytes(bytes);
        return Base64.getEncoder().encodeToString(bytes);
    }

    @Override
    public String creador_usuarios() {
        // No implementa la lógica para crear usuarios, solo contraseñas
        return "";
    }
}
