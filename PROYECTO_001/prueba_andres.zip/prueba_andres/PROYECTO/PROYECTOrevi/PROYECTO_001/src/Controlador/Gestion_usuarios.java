/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.util.UUID;

/**
 *
 * @author COSAS DE LA Y
 */
public class Gestion_usuarios extends Arooz_con_papas {

    @Override
    public String creador_usuarios() {
        // Implementa la lógica para crear usuarios únicos
        return "user_" + UUID.randomUUID().toString();
    }

    @Override
    public String creador_contraseñas() {
        // No implementa la lógica para crear contraseñas, solo usuarios
        return "";
    }
}