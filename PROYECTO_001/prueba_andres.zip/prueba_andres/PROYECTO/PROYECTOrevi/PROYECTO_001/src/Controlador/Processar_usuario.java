/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author COSAS DE LA Y
 */
public class Processar_usuario {
    public static boolean Validar_usuario_contraseña(String usuario, String contraseña) {
      return true;
   
}
}