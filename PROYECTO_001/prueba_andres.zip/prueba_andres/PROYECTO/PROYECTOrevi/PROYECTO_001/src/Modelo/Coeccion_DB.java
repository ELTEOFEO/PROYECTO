package Modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



public class Coeccion_DB {
    private static final String URL = "jdbc:sqlite:universidad.db";

    public Connection conectar() {
        Connection conexion = null;
        try {
            conexion = DriverManager.getConnection(URL);
            System.out.println("Conectado a la base de datos");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return conexion;
    }
}
