/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

public class Guardar_postulante extends Postulante {

    public Guardar_postulante(String nombre, String fecha, String bachillerato, String abanderado, String discapacidad, String carrera, String usuario, String contraseña, boolean estado) {
        super(nombre, fecha, bachillerato, abanderado, discapacidad, carrera, usuario, contraseña, estado);
    }

 

}

