package Controlador;

public abstract class Arooz_con_papas {
    protected abstract String creador_contraseñas();
    protected abstract String creador_usuarios();
}
